/*
	Copyright (C) 2017 Apple Inc. All Rights Reserved.
	See LICENSE.txt for this sample’s licensing information
	
	Abstract:
	(Borrowed from aurioTouch sample code) Part of CoreAudio Utility Classes
*/

#include "CAXException.h"

CAXException::WarningHandler CAXException::sWarningHandler = NULL;
